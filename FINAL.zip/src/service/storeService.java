package service;

import static dao.inputDAO.getInstance;
import static db.JdbcUtil.close;
import static db.JdbcUtil.commit;
import static db.JdbcUtil.getConnection;
import static db.JdbcUtil.rollback;

import java.sql.Connection;
import java.util.ArrayList;

import dao.inputDAO;
import data.GoodsInfoBean;
import data.StoreInfoBean;
import data.UserInfoBean;

public class storeService {

	public ArrayList<GoodsInfoBean> getGoodsList(UserInfoBean uib) {
		inputDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		ArrayList<GoodsInfoBean> golist = 
				dao.getGoList(uib);
		close(con);
		return golist;
	}
	public int regGoods(GoodsInfoBean gib) {
		inputDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		int result = dao.regGoods(gib);
		
		if(result>0) {
			commit(con);
		}else {
			rollback(con);
		}
		close(con);
		return result;
	}
	public int regStore(StoreInfoBean sib) {
		inputDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);		
		
		int result = dao.regStore(sib);
		
		if(result>0) {
			commit(con);
		}else {
			rollback(con);
		}
		close(con);
		return result;
	}
}
