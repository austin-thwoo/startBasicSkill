package service;

import static dao.inputDAO.getInstance;
import static db.JdbcUtil.close;
import static db.JdbcUtil.getConnection;

import java.sql.Connection;
import java.util.ArrayList;

import dao.inputDAO;
import data.GoodsInfoBean;

public class GoodsListService {

	public ArrayList<GoodsInfoBean> getGoodsList(String mbcode) {
		inputDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		ArrayList<GoodsInfoBean> GoodsList;
		
		GoodsList = dao.GoodsList(mbcode);
		
		close(con);
		return GoodsList;
	}

}
