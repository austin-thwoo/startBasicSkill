package data;

public class GoodsInfoBean {
	private String mbcode;
	private String goCode;
	private String goName;
	private String goPrice;
	private String goComment;
	private String filepath;
	private String phone;
	
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getMbcode() {
		return mbcode;
	}
	public void setMbcode(String mbcode) {
		this.mbcode = mbcode;
	}
	public String getFilepath() {
		return filepath;
	}
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
	public String getGoCode() {
		return goCode;
	}
	public void setGoCode(String goCode) {
		this.goCode = goCode;
	}
	public String getGoName() {
		return goName;
	}
	public void setGoName(String goName) {
		this.goName = goName;
	}
	public String getGoComment() {
		return goComment;
	}
	public void setGoComment(String goComment) {
		this.goComment = goComment;
	}
	public String getGoPrice() {
		return goPrice;
	}
	public void setGoPrice(String goPrice) {
		this.goPrice = goPrice;
	}
	
	
}
