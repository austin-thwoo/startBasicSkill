package data;

public class StoreInfoBean {
	private String stmbCode;
	private String stName;
	private String stImg;
	private String stComment;
	
	public String getStComment() {
		return stComment;
	}
	public void setStComment(String stComment) {
		this.stComment = stComment;
	}
	public String getStmbCode() {
		return stmbCode;
	}
	public void setStmbCode(String stmbCode) {
		this.stmbCode = stmbCode;
	}
	public String getStName() {
		return stName;
	}
	public void setStName(String stName) {
		this.stName = stName;
	}
	public String getStImg() {
		return stImg;
	}
	public void setStImg(String stImg) {
		this.stImg = stImg;
	}
	
}
