package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import data.BoardInfoBean;
import data.GoodsInfoBean;



import service.storeService;

/**
 * Servlet implementation class StoreRegGoods
 */
@WebServlet("/RegGoods")
public class StoreRegGoods extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StoreRegGoods() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
	
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		GoodsInfoBean gib = new GoodsInfoBean();
		storeService STsvc  = new storeService();
		// 파일업로드 설정부분
		int size = 10 * 1024 * 1024;
		저장경로가 있는 곳 String savePath = "";		
		MultipartRequest multi = new MultipartRequest(
				request,
				savePath,
				size,
				"UTF-8",
				new DefaultFileRenamePolicy()
				);
		String userId = multi.getParameter("userId");
		gib.setMbcode(multi.getParameter("userId"));
		gib.setGoName(multi.getParameter("goName"));
		gib.setGoPrice(multi.getParameter("goPrice"));
		gib.setGoComment(multi.getParameter("goComment"));
		gib.setFilepath(multi.getOriginalFileName((String)multi.getFileNames().nextElement()));
		
		
		int RegResult = STsvc.regGoods(gib);
		
		if(RegResult>0) {
			RequestDispatcher rd = request.getRequestDispatcher("GoRegSucess.jsp");
			request.setAttribute("userId", userId);
			rd.forward(request, response);
			
		}
		else {
			RequestDispatcher rd = request.getRequestDispatcher("RegFail.jsp");
			request.setAttribute("userId", userId);
			rd.forward(request, response);
			
		}
	}


}
