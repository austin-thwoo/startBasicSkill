package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import data.GoodsInfoBean;
import data.StoreInfoBean;
import service.GoodsListService;
import service.StoreListService;

/**
 * Servlet implementation class StoreGoods
 */
@WebServlet("/StoreGoods")
public class StoreGoods extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StoreGoods() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	request.setCharacterEncoding("UTF-8");
    	response.setContentType("text/html; charset=UTF-8");
    	String mbcode = request.getParameter("mbcode");
    	GoodsListService GoodsListsvc = new GoodsListService();
    	ArrayList<GoodsInfoBean> GoList;
    	
    	GoList=GoodsListsvc.getGoodsList(mbcode);
    	
    	RequestDispatcher dispatcher = request.getRequestDispatcher("GoodsList.jsp");
    	request.setAttribute("GoodsLists", GoList);
    	request.setAttribute("check", "확인용");   	
    	dispatcher.forward(request, response);
    	
    }
    
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
		
	}

}
