package dao;

import java.sql.*;
import java.util.ArrayList;

import static db.JdbcUtil.*;

import data.BoardInfoBean;
import data.GoodsInfoBean;
import data.ModifyBean;
import data.StoreInfoBean;
import data.UserInfoBean;
import data.pageDTO;

import data.BoardInfoBean;
import service.BoardListService;


public class inputDAO {

	private static inputDAO dao;

	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	// getInstance메소드
	public static inputDAO getInstance() {

		if(dao == null) {
			dao = new inputDAO();
		}

		return dao;
	}

	// setConnection 메소드
	public void setConnection(Connection con) {
		this.con = con;
	}

	public int Join(UserInfoBean uib) {
		String sql = "INSERT INTO MEMBERS VALUES(?,?,?,TO_DATE(?,'YYYY-MM-DD'),?,?, DEFAULT)";
		int daoResult = 0;

		try {
			// sql문 작성
			pstmt = con.prepareStatement(sql);

			// ?에 값 입력

			pstmt.setString(1, uib.getUserID());
			pstmt.setString(2, uib.getUserPWD());
			pstmt.setString(3, uib.getUsername());
			pstmt.setString(4, uib.getUserbirth());
			pstmt.setString(5, uib.getUsergender());
			pstmt.setString(6, uib.getUserphone());		

			// db실행 => 결과를 daoResult에 담기
			daoResult = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}

		return daoResult;
	}
	public int LogIn(UserInfoBean uib) {
		int result = 0;

		String sql = "SELECT MB_CODE, MB_PASS, MB_NAME, MB_BI, MB_GENDER, MB_DIGIT, LV_NAME, MB_CODE\r\n" + 
				"FROM MEMBERS\r\n" + 
				"INNER JOIN LEVELS ON MB_LEVEL = LV_CODE\r\n" + 
				"WHERE MB_CODE = ? AND MB_PASS = ?";



		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, uib.getUserID());
			pstmt.setString(2, uib.getUserPWD());

			rs = pstmt.executeQuery();

			if(rs.next()) {
				uib.setUserID(rs.getString(1));
				uib.setUsername(rs.getString(3));
				uib.setUserbirth(rs.getString(4));
				uib.setUsergender(rs.getString(5));
				uib.setUserphone(rs.getString(6));
				uib.setUserlevel(rs.getString(7));
				uib.setStoreCode(rs.getString(8));

				result = 1;
			} else {
				result = 0;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}

		return result;

	}
	public int Modify(UserInfoBean uib) {
		int result = 0;

		String sql = "UPDATE MEMBERS SET MB_PASS = ?, MB_DIGIT = ? WHERE MB_CODE = ?";



		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, uib.getUserPWD());
			pstmt.setString(2, uib.getUserphone());
			pstmt.setString(3, uib.getUserID());

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}

		return result;

	}
	public int Delete(UserInfoBean uib) {
		int result = 0;

		String sql = "DELETE MEMBERS WHERE MB_CODE = ?";



		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, uib.getUserID());

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}

		return result;

	}

	public void overlap(UserInfoBean uib) {
		String result=null;
		String sql = "SELECT MB_CODE FROM MEMBERS WHERE MB_CODE =?";



		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, uib.getUserID());


			rs = pstmt.executeQuery();

			if(rs.next()) {


				result=rs.getString(1);
				uib.setOverlapCheckedId(result);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}
	}

	public ArrayList<GoodsInfoBean> getGoList(UserInfoBean uib) {
		String sql="SELECT * FROM GOODS WHERE GO_STMBCODE = ?";
		ArrayList<GoodsInfoBean> GoList = new ArrayList<GoodsInfoBean>();
		GoodsInfoBean gib = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, uib.getUserID());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				uib.setStoreCode(rs.getString(2));
			}
			while(rs.next()) {
				gib = new GoodsInfoBean();

				gib.setGoCode(rs.getString(2));
				gib.setGoName(rs.getString(3));
				gib.setGoPrice(rs.getString(4));
				gib.setGoComment(rs.getString(5));

				GoList.add(gib);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(pstmt);
			close(rs);
		}
		return GoList;
	}


	public ArrayList<UserInfoBean> MemberList() {
		ArrayList<UserInfoBean> memberList = new ArrayList<UserInfoBean>();
		String sql = "SELECT * FROM MEMBERS";

		try {
			pstmt = con.prepareStatement(sql);

			rs = pstmt.executeQuery();

			while(rs.next()) {

				UserInfoBean uib= new UserInfoBean();
				uib.setUserID(rs.getString(1));
				uib.setUserPWD(rs.getString(2));
				uib.setUsername(rs.getString(3));
				uib.setUserbirth(rs.getString(4));
				uib.setUsergender(rs.getString(5));
				uib.setUserphone(rs.getString(6));
				uib.setUserlevel(rs.getString(7));

				memberList.add(uib);


			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return memberList;
	}

	public UserInfoBean MemberDetail(String userID) {

		String sql = "SELECT MB_CODE, MB_PASS, MB_NAME, MB_BI, MB_GENDER, MB_DIGIT, LV_NAME FROM MEMBERS INNER JOIN LEVELS ON MB_LEVEL = LV_CODE WHERE MB_CODE=?";
		UserInfoBean uib = new UserInfoBean();
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userID);
			rs = pstmt.executeQuery();

			while(rs.next()) {


				uib.setUserID(rs.getString(1));
				uib.setUserPWD(rs.getString(2));
				uib.setUsername(rs.getString(3));
				uib.setUserbirth(rs.getString(4));
				uib.setUsergender(rs.getString(5));
				uib.setUserphone(rs.getString(6));
				uib.setUserlevel(rs.getString(7));

			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return uib;
	}

	public ArrayList<BoardInfoBean> BoardList() {
		String sql = "SELECT * FROM BOARD";

		ArrayList<BoardInfoBean> boardlist = new ArrayList<BoardInfoBean>();
		BoardInfoBean board = null;

		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				board = new BoardInfoBean();

				board.setBdMbcode(rs.getString(1));
				board.setBdNum(rs.getInt(2));
				board.setBdDate(rs.getString(3));
				board.setBdTitle(rs.getString(4));
				board.setBdText(rs.getString(5));
				board.setBdFile(rs.getString(6));
				board.setBdHit(rs.getInt(7));


				boardlist.add(board);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(pstmt);
		}
		return boardlist;
	}

	public int BoardWrite(BoardInfoBean board) {
		String sql = "INSERT INTO BOARD VALUES(?,SEQ_BDCODE.NEXTVAL,SYSDATE,?,?,?,SEQ_CLICKFREQUENCY.NEXTVAL)";
		int writeResult = 0;

		try {
			System.out.println("4.DB");
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, board.getBdMbcode());
			pstmt.setString(2, board.getBdTitle());
			pstmt.setString(3, board.getBdText());
			pstmt.setString(4, board.getBdFile());

			writeResult = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
		}
		return writeResult;
	}

	public int ListCount() {
		String sql = "SELECT COUNT(*) FROM BOARD";
		int listCount = 0;

		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				listCount = rs.getInt(1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}

		return listCount;
	}

	public ArrayList<BoardInfoBean> BoardList(int startRow, int endRow) {
		String sql = "SELECT * FROM BOARD WHERE RN BETWEEN ? AND ?";
		ArrayList<BoardInfoBean> boardList = new ArrayList<BoardInfoBean>();
		BoardInfoBean board= null;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				board = new BoardInfoBean();

				board.setBdMbcode(rs.getString(1));
				board.setBdNum(rs.getInt(2));
				board.setBdDate(rs.getString(3));
				board.setBdTitle(rs.getString(4));
				board.setBdText(rs.getString(5));
				board.setBdFile(rs.getString(6));
				board.setBdHit(rs.getInt(7));


				boardList.add(board);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}
		return boardList;
	}

	public BoardInfoBean BoardView(int bdNum) {
		BoardInfoBean board = new BoardInfoBean();
		String sql = "SELECT * FROM BOARD WHERE BD_NUM = ?";
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bdNum);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				board.setBdMbcode(rs.getString(1));
				board.setBdNum(rs.getInt(2));
				board.setBdDate(rs.getString(3));
				board.setBdTitle(rs.getString(4));
				board.setBdText(rs.getString(5));
				board.setBdFile(rs.getString(6));
				board.setBdHit(rs.getInt(7));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}

		return board;
	}
	public int BoardBhit(int bNum) {
		String sql = "UPDATE BOARD SET BD_HIT = BD_HIT + 1  WHERE BD_NUM=?";
		int hitResult = 0;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bNum);
			hitResult = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(pstmt);
		}

		return hitResult;
	}
	public ArrayList<StoreInfoBean> StoreList() {
		ArrayList<StoreInfoBean> StoreList = new ArrayList<StoreInfoBean>();
		String sql = "SELECT * FROM STORES";

		try {
			pstmt = con.prepareStatement(sql);

			rs = pstmt.executeQuery();
			StoreInfoBean Sib;
			while(rs.next()) {
				Sib = new StoreInfoBean();

				Sib.setStmbCode(rs.getString(1));
				Sib.setStName(rs.getString(2));
				Sib.setStImg(rs.getString(3));
				Sib.setStComment(rs.getString(4));
				StoreList.add(Sib);
			}
			System.out.println("dao test "+ StoreList.get(0).getStImg());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(pstmt);
			close(rs);
		}

		return StoreList;
	}
	public ArrayList<GoodsInfoBean> GoodsList(String mbcode) {
		ArrayList<GoodsInfoBean> GoodsList = new ArrayList<GoodsInfoBean>();
		String sql = "SELECT * FROM GOODS WHERE GO_STMBCODE = ?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mbcode);
			rs = pstmt.executeQuery();
			GoodsInfoBean Gib;
			while(rs.next()) {
				Gib = new GoodsInfoBean();

				Gib.setMbcode(rs.getString(1));
				Gib.setGoCode(rs.getString(2));
				Gib.setGoName(rs.getString(3));
				Gib.setGoPrice(rs.getString(4));
				Gib.setGoComment(rs.getString(5));
				Gib.setFilepath(rs.getString(6));
				GoodsList.add(Gib);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(pstmt);
			close(rs);
		}

		return GoodsList;

	}
	public void getGoodsDetail(GoodsInfoBean goodsInfo) {
		String sql = "SELECT goods.go_stmbcode,goods.go_code,goods.go_name,goods.go_price,goods.go_comment,goods.go_filepath,members.mb_digit "
				+ "FROM GOODS INNER JOIN members ON go_stmbcode = members.mb_code WHERE GO_CODE = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, goodsInfo.getGoCode());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				goodsInfo.setMbcode(rs.getString(1));
				goodsInfo.setGoCode(rs.getString(2));
				goodsInfo.setGoName(rs.getString(3));
				goodsInfo.setGoPrice(rs.getString(4));
				goodsInfo.setGoComment(rs.getString(5));
				goodsInfo.setFilepath(rs.getString(6));
				goodsInfo.setPhone(rs.getString(7));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(pstmt);
			close(rs);
		}


	}
	public int regGoods(GoodsInfoBean gib) {
		String sql = "INSERT INTO GOODS VALUES(?,GO_SEQUENCE.NEXTVAL,?,?,?,?)";
		int daoResult = 0;

		try {
			// sql문 작성
			pstmt = con.prepareStatement(sql);

			// ?에 값 입력
			pstmt.setString(1, gib.getMbcode());
			pstmt.setString(2, gib.getGoName());
			pstmt.setString(3, gib.getGoPrice());
			pstmt.setString(4, gib.getGoComment());
			pstmt.setString(5, gib.getFilepath());
			// db실행 => 결과를 daoResult에 담기
			daoResult = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}

		return daoResult;
	}
	public int regStore(StoreInfoBean sib) {
		String sql = "INSERT INTO STORES VALUES(?,?,?,?)";
		int daoResult = 0;

		try {
			// sql문 작성
			pstmt = con.prepareStatement(sql);

			// ?에 값 입력
			pstmt.setString(1, sib.getStmbCode());
			pstmt.setString(2, sib.getStName());
			pstmt.setString(3, sib.getStImg());
			pstmt.setString(4, sib.getStComment());

			// db실행 => 결과를 daoResult에 담기
			daoResult = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}

		return daoResult;
	}
	public int GoodsMod(GoodsInfoBean gib) {
		int result = 0;

		String sql = "UPDATE GOODS SET GO_NAME = ?, GO_PRICE = ?, GO_COMMENT = ? WHERE GO_CODE = ?";



		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, gib.getGoName());
			pstmt.setString(2, gib.getGoPrice());
			pstmt.setString(3, gib.getGoComment());
			pstmt.setString(4, gib.getGoCode());

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(pstmt);
		}

		return result;

	}

	public int GoodsDel(GoodsInfoBean gib) {
		int result = 0;

		String sql = "DELETE GOODS WHERE GO_CODE = ?";



		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, gib.getGoCode());

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(pstmt);
		}

		return result;

	}

	public int BoardDel(int BdNum) {
		int BoardDelResult = 0;
		String sql = "DELETE BOARD WHERE BD_NUM=?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, BdNum);
			BoardDelResult = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
		}
		return BoardDelResult;
	}

	public int UpdateBoard(BoardInfoBean board) {
		String sql = "UPDATE BOARD SET BD_MBCODE=?, BD_TITLE=?, BD_TEXT=? WHERE BD_NUM=?";
		int UpdateResult = 0;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, board.getBdMbcode());
			pstmt.setString(2, board.getBdTitle());
			pstmt.setString(3, board.getBdText());
			pstmt.setInt(4, board.getBdNum());
			UpdateResult = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
		}
		return UpdateResult;
	}
	public int AdminMod(ModifyBean mob) {
		int result = 0;

		String sql = "UPDATE MEMBERS SET MB_PASS = ?, MB_NAME = ?,MB_BI = ?,MB_GENDER = ?,MB_DIGIT = ?,MB_LEVEL = ? WHERE MB_CODE = ?";



		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mob.getUserPWD());
			pstmt.setString(2, mob.getUsername());
			pstmt.setString(3, mob.getUserbirth());
			pstmt.setString(4, mob.getUsergender());
			pstmt.setString(5, mob.getUserphone());
			pstmt.setString(6, mob.getUserlevel());
			pstmt.setString(7, mob.getUserID());

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}

		return result;

	}
	
	public int MemberDel(String userId) {
		int DelResult = 0;
		String sql = "DELETE MEMBERS WHERE MB_CODE=?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userId);
			DelResult = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
		}
		return DelResult;
	}
}

