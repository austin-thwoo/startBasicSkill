package service;

import static dao.inputDAO.getInstance;
import static db.JdbcUtil.close;
import static db.JdbcUtil.getConnection;

import java.sql.Connection;
import java.util.ArrayList;

import dao.inputDAO;
import data.StoreInfoBean;


public class StoreListService {

	public ArrayList<StoreInfoBean> getStoreList() {
		inputDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		ArrayList<StoreInfoBean> StoreList;
		
		StoreList = dao.StoreList();
		
		close(con);
		return StoreList;
	}

}
