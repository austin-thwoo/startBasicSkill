package service;

import static dao.inputDAO.getInstance;
import static db.JdbcUtil.commit;
import static db.JdbcUtil.getConnection;
import static db.JdbcUtil.rollback;

import java.sql.Connection;

import dao.inputDAO;

public class BoardDelService {

	public int BoardDel(int bdNum) {
		inputDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		
		
		int BoardDelResult = dao.BoardDel(bdNum);
		
		if(BoardDelResult>0) {
			commit(con);
		} else {
			rollback(con);
		}
		
		return BoardDelResult;
	}

}
