package data;

public class BoardInfoBean {

	public	int	 bdNum;
	public String bdMbcode;
	public String bdDate;
	public String bdPass;
	
	public String bdTitle;
	public String bdText;
	public int bdHit;
	public String bdFile;
	
	
	
	public int getBdNum() {
		return bdNum;
	}
	public void setBdNum(int bdNum) {
		this.bdNum = bdNum;
	}
	public String getBdMbcode() {
		return bdMbcode;
	}
	public void setBdMbcode(String bdMbcode) {
		this.bdMbcode = bdMbcode;
	}
	public String getBdDate() {
		return bdDate;
	}
	public void setBdDate(String bdDate) {
		this.bdDate = bdDate;
	}
	public String getBdTitle() {
		return bdTitle;
	}
	public void setBdTitle(String bdTitle) {
		this.bdTitle = bdTitle;
	}
	public String getBdText() {
		return bdText;
	}
	public void setBdText(String bdText) {
		this.bdText = bdText;
	}
	public int getBdHit() {
		return bdHit;
	}
	public void setBdHit(int bdHit) {
		this.bdHit = bdHit;
	}
	public String getBdFile() {
		return bdFile;
	}
	public void setBdFile(String bFile) {
		this.bdFile = bFile;
	}
	public String getBdPass() {
		return bdPass;
	}
	public void setBdPass(String bdPass) {
		this.bdPass = bdPass;
	}
	
}
