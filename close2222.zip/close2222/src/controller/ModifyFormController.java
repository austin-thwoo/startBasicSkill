package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import data.ModifyBean;
import data.UserInfoBean;
import service.joinservice;

/**
 * Servlet implementation class Modify
 */
@WebServlet("/ModifyFormController")
public class ModifyFormController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ModifyFormController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		ModifyBean mob = new ModifyBean();
		int serviceCode = 1;
		int result;
		mob.setUserID(request.getParameter("userID"));
		mob.setUserPWD(request.getParameter("modPassword"));
		mob.setUsername(request.getParameter("modName"));
		mob.setUserbirth(request.getParameter("modDate"));
		mob.setUserphone(request.getParameter("modPhone"));
		mob.setUsergender(request.getParameter("modGender"));
		mob.setUserlevel(request.getParameter("modLevel"));
		System.out.println("mod f controller");
		joinservice jsvc = new joinservice();
		result = jsvc.memberjoin(mob, serviceCode);
		System.out.println("mod f controller" + result);

		if (result>0) {
			RequestDispatcher rd = request.getRequestDispatcher("AdminModSuccess.jsp");
			
			rd.forward(request, response);
		}
		else {
			RequestDispatcher rd = request.getRequestDispatcher("AdminModFail.jsp");
			
			rd.forward(request, response);
		}
	}
}



