package service;

import static dao.inputDAO.*;
import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.inputDAO;
import data.GoodsInfoBean;
import data.ModifyBean;
import data.UserInfoBean;

public class joinservice {
	inputDAO dao = getInstance();
	Connection con = getConnection();

	public int memberjoin(UserInfoBean uib, int serviceCode) {
		int result = 0;
		switch (serviceCode) {
		case 1:
			dao.setConnection(con);
			result = dao.Join(uib);
			if (result>0) {
				commit(con);
				close(con);

			}else {rollback(con);}
			close(con);
			return result;
		case 2:
			dao.setConnection(con);
			result = dao.LogIn(uib);

			if (result>0) {
				commit(con);
				close(con);

			}else {rollback(con);}
			close(con);
			return result;
		case 3:
			dao.setConnection(con);
			result = dao.Modify(uib);

			if (result>0) {
				commit(con);
				close(con);

			}else {rollback(con);}
			close(con);
			return result;
		case 4:
			dao.setConnection(con);
			result = dao.Delete(uib);

			if (result>0) {
				commit(con);
				close(con);

			}else {rollback(con);}
			close(con);
			return result;

		case 5:
			dao.setConnection(con);
			 dao.overlap(uib);
			result=0;
			close(con);
			return result;		
			
			
		default:
			return 0;
		}
		
	}

	public int memberjoin(GoodsInfoBean gib, int serviceCode) {
		int result = 0;
		switch (serviceCode) {
		case 1:
			dao.setConnection(con);
			result = dao.GoodsMod(gib);
			if (result>0) {
				commit(con);
				close(con);

			}else {rollback(con);}
			close(con);
			return result;		
		case 2:
			dao.setConnection(con);
			result = dao.GoodsDel(gib);
			if (result>0) {
				commit(con);
				close(con);

			}else {rollback(con);}
			close(con);
			return result;		
			
		default:
			return 0;
		}
		
	}
	public int memberjoin(ModifyBean mob, int serviceCode) {
		int result = 0;
		switch (serviceCode) {
		case 1:
			dao.setConnection(con);
			result = dao.AdminMod(mob);

			if (result>0) {
				commit(con);
				close(con);

			}else {rollback(con);}
			close(con);
			return result;	
		
			
		default:
			return 0;
		}
		
	}

}