package service;

import static dao.inputDAO.getInstance;
import static db.JdbcUtil.commit;
import static db.JdbcUtil.getConnection;
import static db.JdbcUtil.rollback;

import java.sql.Connection;

import dao.inputDAO;

public class MemberDelService {

	public int MemberDel(String userId) {
		inputDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		
		int delResult = dao.MemberDel(userId);
		
		if(delResult>0) {
			commit(con);
		} else {
			rollback(con);
		}
		
		return delResult;
	}

}
