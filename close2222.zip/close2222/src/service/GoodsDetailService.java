package service;

import static dao.inputDAO.getInstance;
import static db.JdbcUtil.close;
import static db.JdbcUtil.getConnection;

import java.sql.Connection;

import dao.inputDAO;
import data.GoodsInfoBean;

public class GoodsDetailService {

	public void getGoodsDetail(GoodsInfoBean goodsInfo) {
		inputDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		
		dao.getGoodsDetail(goodsInfo);
		
		close(con);
		
	}

}
